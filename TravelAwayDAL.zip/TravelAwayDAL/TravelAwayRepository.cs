using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using TravelAwayDAL.Models;

namespace TravelAwayDAL
{
  public class TravelAwayRepository
    {
        TravelAwayDBContext context;
        public TravelAwayRepository()
        {
            context = new TravelAwayDBContext();
        }

        public string ValidateLoginUsingLinq(string emailId, string password)
        {
            string roleName = "";
            try
            {
                var objUser = (from usr in context.Customers
                               where usr.EmailId == emailId && usr.UserPassword == password
                              select usr.Role).FirstOrDefault<Role>();
                context.SaveChanges();

                if (objUser != null)
                {
                    roleName = objUser.RoleName;
                }
                else
                {
                    roleName = "Invalid credentials";
                }
            }
            catch (Exception)
            {
                roleName = "Invalid credentials";
            }
            return roleName;
        
    }

        #region Employee Login Using Scalar Function

        #endregion
        public int ValidateEmployeeCredentials(string EmailId, string Password)
        {
            int roleId = 0;
            try
            {
                roleId = (from s in context.Employees
                            select TravelAwayDBContext.ufn_ValidateEmployeeCredentials(EmailId, Password))
                             .FirstOrDefault();
            }
            catch (Exception)
            {
                roleId = -99;
            }
            return roleId;

        }

        #region Update Customer- Chandhini

        #endregion
        public bool UpdateCustomerDetails(Customer customer)
        {

            bool status = false;
            Customer cust = context.Customers.Find(customer.EmailId);
            try
            {

                //cartproduct = (from cartProd in context.Cart where cartProd.ProductId == productId && cartProd.EmailId == emailId select cartProd).FirstOrDefault<Cart>();
                if (cust != null)
                {
                    cust.FirstName = customer.FirstName;
                    cust.LastName = customer.LastName;
                    cust.ContactNumber = customer.ContactNumber;
                    cust.Gender = customer.Gender;
                    cust.DateOfBirth = customer.DateOfBirth;
                    cust.Address = customer.Address;
                    cust.EmailId = customer.EmailId;
                    context.SaveChanges();
                    status = true;

                }
                else
                {
                    status = false;
                }
            }
            catch (Exception ex)
            {
                status = false;
                Console.WriteLine(ex.Message);
            }
            return status;
        }

   public int RegisterNewCustomer(Customer newCust)
        {
            int result;
            try
            {
                SqlParameter prmFirstName = new SqlParameter("@firstName", newCust.FirstName);
                SqlParameter prmLastName = new SqlParameter("@lastName", newCust.LastName);
                SqlParameter prmPassword = new SqlParameter("@userPassword", newCust.UserPassword);
                SqlParameter prmGender = new SqlParameter("@gender", newCust.Gender);
                SqlParameter prmEmailId = new SqlParameter("@emailId", newCust.EmailId);
                SqlParameter prmDob = new SqlParameter("@dateOfBirth", newCust.DateOfBirth);
                SqlParameter prmNumber = new SqlParameter("@contactNumber", newCust.ContactNumber);
                SqlParameter prmAddress = new SqlParameter("@address", newCust.Address);

                SqlParameter prmReturnResult = new SqlParameter("@ReturnResult", System.Data.SqlDbType.Int);
                prmReturnResult.Direction = System.Data.ParameterDirection.Output;

                result = context.Database.ExecuteSqlRaw("EXEC @ReturnResult= usp_RegisterCustomer @emailId,@firstName,@lastName,@userPassword, " +
                    "@gender,@contactNumber,@dateOfBirth,@address",
                    prmReturnResult, prmEmailId, prmFirstName, prmLastName, prmPassword, prmGender, prmNumber, prmDob, prmAddress);
                if (result > 0)
                {
                    return result;
                }
                else
                {
                    result = -98;
                    return result;
                }
            }
            catch(Exception e)
            {
                result = -99;
                return result;
            }
            
        }

  public bool EditProfile(Customer cust)
        { 
            bool status = false;
            Customer cust1 = context.Customers.Find(cust.EmailId);
            try
            { 
                if(cust1 != null)
                {
                    cust1.FirstName = cust.FirstName;
                    cust1.LastName = cust.LastName;
                    cust1.ContactNumber = cust.ContactNumber;
                    cust1.Address = cust.Address;
                    cust1.Gender = cust.Gender;
                    cust1.DateOfBirth = cust.DateOfBirth;
                    context.SaveChanges();
                    status = true;
                }
                else
                {
                    status = false;
                }
            }
            catch(Exception e)
            {
                status = false;
                Console.WriteLine(e.Message);
            }
            return status;
        }

        public List<Package> GetPackages()
        {
            List<Package> package;
            try
            {
                package = context.Packages.FromSqlRaw("SELECT * FROM dbo.ufn_ViewAllPackages()").ToList();
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
                package = null;
            }
            return package;
        }
  public List<PackageCategory> GetPackageCategories()
        {
            {
                List<PackageCategory> obj = null;
                try
                {
                    obj = (from a in context.PackageCategories select a).ToList();
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    obj = null;
                }
                return obj;
            }

        }

        public List<Vehicle> GetVehicles()
        {
            {
                List<Vehicle> obj = null;
                try
                {
                    obj = (from a in context.Vehicles select a).ToList();
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    obj = null;
                }
                return obj;
            }

        }

    public List<PackageDetail> GetPackageDetailsByPackageId(int packageId)
        {
            List<PackageDetail> obj = null;
            try
            {
                obj = (from a in context.PackageDetails where a.PackageId== packageId select a).ToList();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                obj = null;
            }
            return obj;
        }

   public bool AddNewHotel(Hotel obj)
        {
            bool result;
            try
            {
                context.Hotels.Add(obj);
                context.SaveChanges();
                result = true;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                result = false;
            }
            return result;
        }

        public bool AddNewVehicle(Vehicle obj)
        {
            bool result;
            try
            {
                context.Vehicles.Add(obj);
                context.SaveChanges();
                result = true;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                result = false;
            }
            return result;
        }

        
    }
}
