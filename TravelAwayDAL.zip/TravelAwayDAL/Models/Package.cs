﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TravelAwayDAL.Models
{
    public partial class Package
    {
        public Package()
        {
            PackageDetails = new HashSet<PackageDetail>();
        }

        public int PackageId { get; set; }
        public string PackageName { get; set; }
        public int? PackageCategoryId { get; set; }
        public string TypeOfPackage { get; set; }

        public virtual PackageCategory PackageCategory { get; set; }
        public virtual ICollection<PackageDetail> PackageDetails { get; set; }
    }
}
