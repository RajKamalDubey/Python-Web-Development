﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TravelAwayDAL.Models
{
    public partial class Booking
    {
        public Booking()
        {
            Payments = new HashSet<Payment>();
        }

        public string EmailId { get; set; }
        public int BookingId { get; set; }
        public int? PackageId { get; set; }
        public decimal ContactNumber { get; set; }
        public string Address { get; set; }
        public DateTime DateOfTravel { get; set; }
        public int NumberOfAdults { get; set; }
        public int? NumberOfChildren { get; set; }
        public string Status { get; set; }

        public virtual Customer Email { get; set; }
        public virtual ICollection<Payment> Payments { get; set; }
    }
}
