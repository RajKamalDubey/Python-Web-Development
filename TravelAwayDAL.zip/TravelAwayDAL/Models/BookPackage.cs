﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TravelAwayDAL.Models
{
    public partial class BookPackage
    {
        public string EmailId { get; set; }
        public int BookingId { get; set; }
        public decimal ContactNumber { get; set; }
        public string Address { get; set; }
        public DateTime DateOfTravel { get; set; }
        public int NumOfAdults { get; set; }
        public int? NumOfChildren { get; set; }
        public string Status { get; set; }
        public int? PackageId { get; set; }

        public virtual Customer Email { get; set; }
        public virtual PackageDetail Package { get; set; }
    }
}
