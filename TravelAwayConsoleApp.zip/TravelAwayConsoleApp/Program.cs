﻿using System;
using TravelAwayDAL;

namespace TravelAwayConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            TravelAwayRepository repository = new TravelAwayRepository();

            Console.WriteLine("Hello World!");
        }
    }
}
