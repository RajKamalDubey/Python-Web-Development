import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { IEmployee } from '../../app/travelAway-interfaces/Employee';
import { ICustomer } from '../../app/travelAway-interfaces/Customer';
import { IHotel } from '../../app/travelAway-interfaces/Hotel';
import { IVehicle } from '../../app/travelAway-interfaces/Vehicle';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  constructor(private http: HttpClient) {
  
  }
  //for login
  validateCredentials(email: string, password: string,loginRole: number): Observable<number> {
    let temp;
    if (loginRole == 1) {
      var custObj: ICustomer;
     // custObj = { EmailId: email, UserPassword: password, FirstName:null,LastName:null,RoleId: null,Gender:null,DateOfBirth: null, Address: null,ContactNumber:null};
      temp = this.http.post<string>('https://localhost:44334/api/Customer/ValidateUserCredentials' + "?emailId=" + email + "&" + "password=" + password, " ").pipe(catchError(this.errorHandler));
    } else if (loginRole == 2) {
      var EmpObj: IEmployee;
      EmpObj = { EmailId: email, Password: password, FirstName: null, LastName: null, RoleId:null};
      temp = this.http.post<number>('https://localhost:44334/api/Customer/ValidateEmployeeCredentials',EmpObj).pipe(catchError(this.errorHandler))

    }
    return temp;
  }

  updateUserDetails(firstName: string, lastName: string, emailId: string,
    password: string, contactNumber: number, address: string, gender: string, dateOfBirth: Date, roleId: number): Observable<boolean> {
    var custObj: ICustomer;
    custObj = { EmailId: emailId, UserPassword: password, FirstName: firstName, LastName: lastName, RoleId: roleId, Gender: gender, DateOfBirth: dateOfBirth, Address: address, ContactNumber: contactNumber };
    let temp = this.http.put<boolean>('https://localhost:44334/api/Customer/UpdateCustomer', custObj).pipe(catchError(this.errorHandler));
    return temp;
  }

  //for register
  addUserDetails(firstName: string, lastName: string, emailId: string,
    password: string, contactNumber: number, address: string, gender: string, dateOfBirth: Date, roleId: number): Observable<number> {
    var custObj: ICustomer;
    custObj = { EmailId: emailId, UserPassword: password, FirstName: firstName, LastName: lastName, RoleId: roleId, Gender: gender, DateOfBirth: dateOfBirth, Address: address, ContactNumber: contactNumber };
    let temp = this.http.post<number>('https://localhost:44334/api/Customer/AddCustomer', custObj).pipe(catchError(this.errorHandler));
    return temp;
  }

  addHotel(hotel: IHotel): Observable<boolean> {
    let temp = this.http.post<boolean>('https://localhost:44334/api/Customer/AddHotel', hotel).pipe(catchError(this.errorHandler));
    return temp;
  }

  addVehicle(vehicle: IVehicle): Observable<boolean> {
    let temp = this.http.post<boolean>('https://localhost:44334/api/Customer/AddVehicle', vehicle).pipe(catchError(this.errorHandler));
    return temp;
  }


    errorHandler(error: HttpErrorResponse) {
      console.error(error);
      return throwError(error.message || "Server Error");
    }
  }
