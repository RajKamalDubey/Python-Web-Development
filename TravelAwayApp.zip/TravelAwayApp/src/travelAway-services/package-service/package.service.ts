import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { IPackage } from 'src/app/travelAway-interfaces/Package';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { ICategory } from '../../app/travelAway-interfaces/Category';
import { IPackageDetails } from '../../app/travelAway-interfaces/PackageDetails';

@Injectable({
  providedIn: 'root'
})
export class PackageService {

  constructor(private http: HttpClient) { }

  getPackages(): Observable<IPackage[]> {
    let temp = this.http.get<IPackage[]>('https://localhost:44334/api/Customer/GetPackages').pipe(catchError(this.errorHandler))
    return temp;
  }

  getCategories(): Observable<ICategory[]> {
    return this.http.get<ICategory[]>('https://localhost:44334/api/Customer/GetPackageCategories').pipe(catchError(this.errorHandler));
  }
  getPackageDetails(packageId: string): Observable<IPackageDetails[]> {
    let PackageId = { packageId: packageId };
    let temp = this.http.get<IPackageDetails[]>('https://localhost:44334/api/Customer/GetPackageDetailsByPackageId', { params: PackageId }).pipe(catchError(this.errorHandler));
    return temp;
  }

  errorHandler(error: HttpErrorResponse) {
    console.error(error);
    return throwError(error.message || "Server Error");
  }
}
