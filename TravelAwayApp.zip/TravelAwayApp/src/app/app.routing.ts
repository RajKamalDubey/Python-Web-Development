import { RouterModule, Routes } from '@angular/router';
import { ModuleWithProviders } from '@angular/core';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { UpdateCustomerComponent } from './update-customer/update-customer.component';
import { ViewPackageDetailsComponent } from './view-package-details/view-package-details.component';
import { AddVehicleComponent } from './add-vehicle/add-vehicle.component';
import { AddHotelComponent } from './add-hotel/add-hotel.component';
import { ViewPackagesComponent } from './view-packages/view-packages.component';
import { RegisterComponent } from './register/register.component';

const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'home', component: HomeComponent },
  { path: 'login/:loginRole', component: LoginComponent },
  { path: 'addvehicle', component: AddVehicleComponent },
  { path: 'addhotel', component: AddHotelComponent },
  { path: 'viewPackages', component: ViewPackagesComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'viewPackageDetails/:packageId/:packageName', component: ViewPackageDetailsComponent },
  { path: 'editDetails', component: UpdateCustomerComponent },
 
  { path: '**', component: HomeComponent }
];
export const routing: ModuleWithProviders = RouterModule.forRoot(routes);
