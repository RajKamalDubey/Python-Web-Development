import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { CustomerService } from '../../travelAway-services/customer-service/customer.service';
import { ICustomer } from '../travelAway-interfaces/Customer';


@Component({
  selector: 'app-update-customer',
  templateUrl: './update-customer.component.html',
  styleUrls: ['./update-customer.component.css']
})
export class UpdateCustomerComponent implements OnInit {
  msg: string;
  emailId: string;
  errorMsg: any;
  status: boolean;
  firstName: string;
  lastName: string;
  contact: number;
  dob: Date;
  Address: string;
  userRole: string;
  gender: string;
  customer: ICustomer;
  showDiv: boolean = true;
  customerLayout: boolean = false;
  commonLayout: boolean = false;
  constructor(private router: Router, private cService: CustomerService, private ac: ActivatedRoute) {
    this.emailId = sessionStorage.getItem("userName");
    this.userRole = sessionStorage.getItem('userRole');
    if (this.userRole != "Customer") {
      this.router.navigate(['/login/1']);
    } else if (this.userRole == "Customer") {
      this.customerLayout = true;
    }
  }

  ngOnInit(): void {


  }

SubmitForm(form: NgForm) {
    this.cService.updateUserDetails(form.value.firstName, form.value.lastName, this.emailId,
      null, parseInt(form.value.contactNumber), form.value.address, form.value.gender, new Date(form.value.dateOfBirth), 1).subscribe(
        responseUpdateStatus => {
          this.status = responseUpdateStatus;
          this.showDiv = true;
          if (this.status == true) {
            this.msg = "Updation Successfully";


          } else {
            this.msg = "Not able to update";
          }
        },
        responseUpdateError => {
          this.errorMsg = responseUpdateError;
        },
        () => console.log("Updated method executed successfully")
      );
  }

}


