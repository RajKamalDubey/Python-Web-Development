export interface IHotel {
  hotelName: string,
  hotelRating: number,
  singleRoomPrice: number,
  doubleRoomPrice: number,
  deluxeeRoomPrice: number,
  suiteRoomPrice: number,
  city: string
}
