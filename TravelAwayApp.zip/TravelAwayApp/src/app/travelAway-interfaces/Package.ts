export interface IPackage {
  PackageId: number,
  PackageName: string,
  packageCategoryId: number,
  TypeOfPackage:string
}
