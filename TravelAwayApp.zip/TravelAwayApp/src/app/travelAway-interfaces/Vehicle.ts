export interface IVehicle {
  vehicleName: string,
  vehicleType: string,
  ratePerHour: number,
  ratePerKm: number,
  basePrice: number
}
