export interface ICustomer {
  EmailId: string,
  UserPassword: string,
  FirstName: string,
  LastName: string,
  RoleId: number,
  Gender: string,
  DateOfBirth: Date,
  Address: string,
  ContactNumber:number
}
