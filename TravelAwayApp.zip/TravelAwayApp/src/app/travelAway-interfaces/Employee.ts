export interface IEmployee {
  EmailId: string,
  Password: string,
  FirstName: string,
  LastName: string,
  RoleId: number
}
