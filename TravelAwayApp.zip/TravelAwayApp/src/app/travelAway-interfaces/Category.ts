export interface ICategory {
  EmailId: string,
  PackageCategoryName: string
}
