export interface IcustCare {
  bookingId: number,
  query: string,
  queryStatus: string,
  assignee: number
}
