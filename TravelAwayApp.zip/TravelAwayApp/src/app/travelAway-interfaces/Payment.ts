export interface IPayment{
  bookingId: number,
  totalAmount: number,
  paymentStatus: string
}
