import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { PackageService } from '../travelAway-services/package-service/package.service';
import { HttpClientModule } from '@angular/common/http';
import { routing } from './app.routing';
import { CommonLayoutComponent } from './layouts/common-layout/common-layout.component';
import { UserLayoutComponent } from './layouts/user-layout/user-layout.component';
import { EmployeeLayoutComponent } from './layouts/employee-layout/employee-layout.component';
import { CustomerService } from '../travelAway-services/customer-service/customer.service';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { AddHotelComponent } from './add-hotel/add-hotel.component';
import { AddVehicleComponent } from './add-vehicle/add-vehicle.component';
import { RegisterComponent } from './register/register.component';
import { ViewPackagesComponent } from './view-packages/view-packages.component';
import { ViewPackageDetailsComponent } from './view-package-details/view-package-details.component';
import { UpdateCustomerComponent } from './update-customer/update-customer.component';
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    CommonLayoutComponent,
    UserLayoutComponent,
    EmployeeLayoutComponent,
    AddHotelComponent,
    AddVehicleComponent,
    RegisterComponent,
    UpdateCustomerComponent,
    ViewPackagesComponent,
    ViewPackageDetailsComponent,
  

  ],
  imports: [
    BrowserModule, HttpClientModule, FormsModule, ReactiveFormsModule,routing
  ],
  providers: [PackageService, CustomerService],
  bootstrap: [AppComponent]
})
export class AppModule { }
