﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using TravelAwayDAL;
using TravelAwayDAL.Models;




namespace TravelAwayServices.Controllers
{
    //[Route("api/[controller]")]
    [Route("api/[controller]/[action]")]
    [ApiController]
    //public class CustomerController : ControllerBase
    public class CustomerController : Controller
    {
        TravelAwayRepository repository;
        public CustomerController()
        {
            repository = new TravelAwayRepository();
        }

        [HttpPost]
        public JsonResult ValidateUserCredentials(string emailId, string password)
        {
            string role;
            int roleId = 0;
            try
            {
                var dal = new TravelAwayRepository();
                role = dal.ValidateLoginUsingLinq(emailId, password);
                if (role == "Customer")
                {
                    roleId = 1;
                }
            }
            catch (Exception)
            {
                role = "Invalid credentials";
                roleId = -1;
            }

            return Json(roleId);
        }

        [HttpPost]
        public JsonResult ValidateEmployeeCredentials(Employee CObj)

        {
            int roleId = -1;

            try
            {
                var dal = new TravelAwayRepository();
                roleId = dal.ValidateEmployeeCredentials(CObj.EmailId, CObj.Password);


            }
            catch (Exception)
            {
                roleId = -90; }
            return Json(roleId);

        }

        public bool UpdateCustomer(Customer cust)
        {

            bool status;
            try
            {
                status = repository.UpdateCustomerDetails(cust);
            }
            catch (Exception)
            {

                status = false;
            }
            return status;
        }

        [HttpGet]
        public JsonResult GetPackages()
        {
            List<Package> packageList;
            try
            {
                packageList = repository.GetPackages();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                packageList = null;
            }
            return Json(packageList);
        }

        [HttpGet]
        public JsonResult GetPackageCategories()
        {
            List<PackageCategory> packageCategoriesList;
            try
            {
                packageCategoriesList = repository.GetPackageCategories();
            }
            catch (Exception)
            {
                packageCategoriesList = null;
            }
            return Json(packageCategoriesList);
        }

        // API to get a list of package filtered by categoryId
        //[HttpGet]
        //public JsonResult GetPackagesByCategoryId(int categoryId)
        //{
        //    List<Package> packageList;
        //    try
        //    {
        //        packageList = repository.GetPackagesByCategoryId(categoryId);
        //    }
        //    catch (Exception)
        //    {
        //        packageList = null;
        //    }
        //    return Json(packageList);
        //}

        // API to get package details for given packageId
        [HttpGet]
        public JsonResult GetPackageDetailsByPackageId(string packageId)
        {
            List<PackageDetail> packageDetails;
            try
            {
                int Id = Convert.ToInt32(packageId);
                packageDetails = repository.GetPackageDetailsByPackageId(Id);
            }
            catch (Exception)
            {
                packageDetails = null;
            }
            return Json(packageDetails);
        }

        [HttpPost]
        public int AddCustomer(Customer custObj)
        {
            int role;
            try
            {
                role = repository.RegisterNewCustomer(custObj);
            }
            catch (Exception)
            {
                role = -99;
            }
            return role;
        }


        [HttpPost]
        public bool AddHotel(Hotel hotel)
        {
            bool status;
            try
            {
                status = repository.AddNewHotel(hotel);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                status = false;
            }
            return status;
        }

        // API to add a vehivle by Admin
        [HttpPost]
        public bool AddVehicle(Vehicle vehicle)
        {
            bool status;
            try
            {
                status = repository.AddNewVehicle(vehicle);
            }
            catch (Exception)
            {
                status = false;
            }
            return status;
        }
       
        #region - UPDATE
        // API to update user details
        [HttpPut]
        public bool UpdateProfile(Customer custObj)
        {
            bool status;
            try
            {
                status = repository.UpdateCustomerDetails(custObj);
            }
            catch (Exception)
            {
                status = false;
            }
            return status;
        }
        #endregion

    }
}
